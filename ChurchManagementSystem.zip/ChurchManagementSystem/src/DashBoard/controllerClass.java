package DashBoard;

import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;

import java.net.URL;
import java.util.ResourceBundle;

public class controllerClass implements Initializable {

    @FXML
    private javafx.scene.layout.AnchorPane AnchorPane;

    @FXML
    private JFXButton Addmemberbtn;

    @FXML
    private JFXButton Financialbtn;

    @FXML
    private JFXButton Updatebtn;

    @FXML
    private JFXButton Viewmemberbtn;

    @FXML
    private JFXButton Programbtn;

    @FXML
    private JFXButton Settingsbtn;

    @FXML
    private GridPane Gridpane;

    @FXML
    private Pane Headpane;

    @FXML
    void Addmember(ActionEvent event) {

    }

    @FXML
    void Buttonparent(MouseEvent event) {

    }

    @FXML
    void Financial(ActionEvent event) {

    }

    @FXML
    void Schedule(ActionEvent event) {

    }

    @FXML
    void Settings(ActionEvent event) {

    }

    @FXML
    void Update(ActionEvent event) {

    }

    @FXML
    void Viewmember(ActionEvent event) {

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
