package DisplayMembers;

import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

public class displayController implements Initializable {
    //declare your text fields over here


    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
